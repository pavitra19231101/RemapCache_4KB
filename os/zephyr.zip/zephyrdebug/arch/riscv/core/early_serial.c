
#include <kernel.h>
#include <sys/util.h>
#include <soc.h>

#define STDOUTREG_ADDRESS 0x310
#define CONFIG_CONSOLE_BUFFER_SIZE 0x480

int pos_console = 0;
/* Write to a specific memory location.  */
void arch_printk_char_out(int c)
{
  unsigned int key_console = irq_lock();
  volatile int* serial = (int*)STDOUTREG_ADDRESS;
  serial[pos_console] = c; // sys_write 8
  pos_console = (pos_console + 1) % CONFIG_CONSOLE_BUFFER_SIZE;
  irq_unlock(key_console);
}

